window.onscroll = function(){
let targetElements = document.querySelectorAll(".digit-box");
let animationtiming = 4000;

targetElements.forEach((targetElements) => {
  let valueOne = 0;
  let valueTwo = parseInt(targetElements.getAttribute("data-val"));
  let timing = Math.floor(animationtiming / valueTwo);
  let counter = setInterval(function () {
    valueOne += 1;
    targetElements.textContent = valueOne;
    if(valueOne == valueTwo){
        clearInterval(counter);
    }
  }, timing)
})
}


function toggleBtn(){
  document.getElementById('heaber').classList.toggle('active');
 }

$('.owl-carousel').owlCarousel({
  loop:true,
  margin:25,
  nav:true,
  autoplay:true,
  autoplayTimeout:3000,
  responsiveClass:true,
  autoplayHoverPause:true,
  responsive:{
      0:{
          items:1.2
      },
      600:{
          items:3
      },
      1000:{
          items:4
      }
  }
})
